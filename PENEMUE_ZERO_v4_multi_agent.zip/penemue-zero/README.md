# PENEMUE ZERO — iPhone-friendly starter

This is a starter codebase, not a deployed public app, a new foundation model, or a copy of GPT-6.

## Included
- Mobile-first installable web app UI
- Server-side model API integration and web search
- Password gate for a single-owner prototype
- SQLite chat history and editable saved memories
- Research task queue with saved results, editable personality customization, and JSON export/import
- Multi-agent research pipeline: planner → web-searching investigator and independent skeptic in parallel → evidence-aware synthesis
- Relevance-ranked memory retrieval for chat and research context
- PENEMUE ZERO persona and research instructions

## Run and deploy
Requires Node.js 20+ and a host with persistent disk.
1. Run `npm install`.
2. Copy `.env.example` to `.env`.
3. Set `OPENAI_API_KEY`, `OPENAI_MODEL`, `APP_PASSWORD`, and a long random `SESSION_SECRET`.
4. Run `npm start`.
5. Open the hosted HTTPS URL.

Keep API keys only in server-side environment variables. Never place them in browser JavaScript or public files. Use HTTPS. Persistent storage is required for the SQLite database. The included password gate is a prototype; add proper user accounts, CSRF protection, rate limiting, backups, and a security review before public release.

## Add to iPhone Home Screen
Once deployed on HTTPS, open the URL in Safari → Share → Add to Home Screen → Add.

## Limitations
- Uses the GPT-6.2 Astra API model by default (configurable); model quality, availability, pricing, and provider policies apply.
- Does not copy private GPT-6 weights, hidden prompts, internal tools, or safeguards.
- Does not import the user's full ChatGPT history. Manually add relevant memories or build a consent-based export/import feature.
- Research jobs are created and saved in a queue, then run when you tap Run research. Each run makes four model calls (planning, investigator, skeptic, synthesis), so API costs and latency are higher than a single answer. There is no continuous background scheduler or 300 full investigations/hour.
- Memory retrieval currently ranks saved entries by simple keyword overlap; it is not semantic/vector retrieval and may miss relevant memories.
- The model name is configurable; verify your API account has access to the selected model.

## Next engineering phases
1. Account system, secure onboarding, recovery, CSRF protection, and rate limits.
2. Consent-based ChatGPT export/import and memory review/export/deletion.
3. Research task queue with concurrency limits, retries, cost budgets, and audit logs.
4. Evidence database for questions, claims, sources, confidence, and falsification tests.
5. Multiple model providers and task-based routing with evaluation benchmarks.
6. File retrieval, voice/image inputs, project workspaces, and backups.

## Data portability and research tasks
The Research tab stores questions and results in SQLite. A task runs only when you press its run button. The Settings tab lets you add persona preferences and export/import PENEMUE JSON data. Imports append memories and messages; they do not erase existing data. Do not import untrusted JSON files.

On first launch, the app seeds a small set of PENEMUE ZERO project memories (mission, research standards, iPhone target, and the hourly discovery automation) if the memory table is empty. This is a project summary, not a full import of ChatGPT conversations.

## Additional hardening in this build
- Login, chat, and research execution endpoints have basic in-process request throttles.
- Mutating requests with an Origin header are restricted to the app's own host.
- The iPhone web app includes a manifest, app icon, and cached app shell. Chat and research still require network access.
- These are prototype protections, not a substitute for a production security review, robust multi-user authentication, persistent rate limiting, or encrypted backups.
